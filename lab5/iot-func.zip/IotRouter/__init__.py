import logging
import os
import json
from datetime import datetime
from azure.storage.queue import QueueClient
import azure.functions as func

# Settings read from Function App configuration
STORAGE_CONN = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
QUEUE_NAME = os.getenv("QUEUE_NAME", "iot-telemetry-raw")

if not STORAGE_CONN:
    logging.warning("AZURE_STORAGE_CONNECTION_STRING not set. Function will fail at runtime if used without setting it.")

queue_client = None
def get_queue_client():
    global queue_client
    if queue_client is None:
        queue_client = QueueClient.from_connection_string(STORAGE_CONN, QUEUE_NAME)
        # ensure queue exists (no-op if exists)
        try:
            queue_client.create_queue()
        except Exception:
            # ignore if already exists or permission errors surface later
            pass
    return queue_client

def validate_payload(payload):
    # basic validation — you can expand as needed
    required = ["device_id", "sensor_type", "timestamp", "value"]
    missing = [k for k in required if k not in payload]
    return missing

async def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("IngestSensorData called")
    try:
        body = req.get_body().decode("utf-8")
        data = json.loads(body)
    except Exception as e:
        logging.error("Invalid JSON: %s", e)
        return func.HttpResponse(json.dumps({"error": "Invalid JSON"}), status_code=400, mimetype="application/json")

    missing = validate_payload(data)
    if missing:
        return func.HttpResponse(json.dumps({"error": "missing_fields", "fields": missing}), status_code=400, mimetype="application/json")

    # Optionally enrich with server-side timestamp/metadata
    data.setdefault("received_at", datetime.utcnow().isoformat() + "Z")

    # Enqueue message (store raw JSON)
    try:
        qc = get_queue_client()
        # Queue messages accept only text up to ~64KB (base64 or plain JSON fine). We push raw JSON string.
        msg_text = json.dumps(data)
        res = qc.send_message(msg_text)
        msg_id = getattr(res, "message_id", None)
        logging.info("Enqueued message to queue '%s' id=%s", QUEUE_NAME, msg_id)
    except Exception as e:
        logging.exception("Failed to enqueue to queue: %s", e)
        return func.HttpResponse(json.dumps({"error": "enqueue_failed", "details": str(e)}), status_code=500, mimetype="application/json")

    return func.HttpResponse(json.dumps({"status": "accepted", "queue": QUEUE_NAME, "message_id": msg_id}), status_code=202, mimetype="application/json")
